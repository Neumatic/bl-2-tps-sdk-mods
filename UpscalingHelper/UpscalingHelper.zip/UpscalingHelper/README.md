# Changelog

## Upscaling Helper 1.0
- Initial Release.
