# Changelog

## Upscaling Helper 1.1
- Changed Resolution Scale to use round instead of int.

## Upscaling Helper 1.0
- Initial Release.
